"use client";
import { useSearchParams } from "next/navigation";
import { useState } from "react";
export default function CheckoutPage() {
  const params = useSearchParams();
  const product = params.get("product");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  async function checkout() {
    if (!product) return;
    setLoading(true);
    setError("");
    const response = await fetch("/api/stripe/create-checkout", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId: product }),
    });
    const body = await response.json();
    if (!response.ok) {
      setError(body.error ?? "Unable to start checkout.");
      setLoading(false);
      return;
    }
    window.location.href = body.url;
  }
  return (
    <main className="container">
      <h1>Checkout</h1>
      <p className="muted">You will be redirected to Stripe-hosted checkout.</p>
      <button className="button" disabled={loading || !product} onClick={checkout}>
        {loading ? "Opening checkout..." : "Continue to checkout"}
      </button>
      {error && <p>{error}</p>}
    </main>
  );
}
