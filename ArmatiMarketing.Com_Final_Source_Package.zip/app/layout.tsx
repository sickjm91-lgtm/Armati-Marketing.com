import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "ArmatiMarketing.Com",
  description: "AI-powered websites and ready-to-go online businesses.",
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
