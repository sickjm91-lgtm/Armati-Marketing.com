import { NextResponse } from "next/server";
import Stripe from "stripe";
import { createAdminSupabaseClient } from "@/lib/supabase/admin";
export async function POST(request: Request) {
  const signature = request.headers.get("stripe-signature");
  if (!signature) return new NextResponse("Missing signature", { status: 400 });
  const rawBody = await request.text();
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      rawBody,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (error) {
    console.error("Stripe signature verification failed", error);
    return new NextResponse("Invalid signature", { status: 400 });
  }
  const supabase = createAdminSupabaseClient();
  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId = session.metadata?.user_id;
        const productId = session.metadata?.product_id;
        if (userId && productId) {
          await supabase.from("billing_events").insert({
            stripe_event_id: event.id,
            event_type: event.type,
            user_id: userId,
            product_id: productId,
            payload: event,
          });
        }
        break;
      }
      case "customer.subscription.created":
      case "customer.subscription.updated":
      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription;
        const userId = subscription.metadata?.user_id;
        const productId = subscription.metadata?.product_id;
        if (userId) {
          await supabase.from("subscriptions").upsert({
            stripe_subscription_id: subscription.id,
            stripe_customer_id: typeof subscription.customer === "string" ? subscription.customer : null,
            user_id: userId,
            product_id: productId ?? null,
            status: subscription.status,
            current_period_end: new Date(subscription.items.data[0]?.current_period_end * 1000).toISOString(),
            updated_at: new Date().toISOString()
          }, { onConflict: "stripe_subscription_id" });
        }
        break;
      }
      case "invoice.payment_failed": {
        await supabase.from("billing_events").insert({
          stripe_event_id: event.id,
          event_type: event.type,
          payload: event,
        });
        break;
      }
    }
    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("Webhook processing failed", error);
    return new NextResponse("Webhook processing failed", { status: 500 });
  }
}
