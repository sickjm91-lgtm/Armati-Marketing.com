import { requireUser } from "@/lib/auth";
import { createServerSupabaseClient } from "@/lib/supabase/server";
export default async function DashboardPage() {
  const user = await requireUser();
  const supabase = await createServerSupabaseClient();
  const { data: memberships } = await supabase
    .from("workspace_members")
    .select("workspace_id,role,workspaces(id,name,slug)")
    .eq("user_id", user.id);
  return (
    <main className="container">
      <h1>Customer Dashboard</h1>
      <p className="muted">Signed in as {user.email}</p>
      <div className="grid">
        {(memberships ?? []).map((membership) => (
          <div className="card" key={membership.workspace_id}>
            <h2>{membership.workspaces?.name ?? "Workspace"}</h2>
            <p>Role: {membership.role}</p>
            <p>Workspace ID: {membership.workspace_id}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
