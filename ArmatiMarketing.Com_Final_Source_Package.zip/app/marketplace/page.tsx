import Link from "next/link";
import { createServerSupabaseClient } from "@/lib/supabase/server";
export default async function MarketplacePage() {
  const supabase = await createServerSupabaseClient();
  const { data: products } = await supabase
    .from("marketplace_products")
    .select("id,name,slug,description,price_cents,currency")
    .eq("active", true)
    .order("created_at", { ascending: false });
  return (
    <main className="container">
      <h1>Ready-to-go businesses</h1>
      <p className="muted">Choose a package, then customize it inside your workspace.</p>
      <div className="grid">
        {(products ?? []).map((product) => (
          <article className="card" key={product.id}>
            <h2>{product.name}</h2>
            <p className="muted">{product.description}</p>
            <p><strong>{product.currency.toUpperCase()} {(product.price_cents / 100).toFixed(2)}</strong></p>
            <Link className="button" href={`/checkout?product=${product.id}`}>Buy / subscribe</Link>
          </article>
        ))}
      </div>
    </main>
  );
}
