insert into public.templates (name, slug, version, schema)
values (
  'Professional Local Business',
  'professional-local-business',
  1,
  '{"theme":"professional","pages":["home","about","services","contact"]}'::jsonb
)
on conflict (slug) do nothing;
insert into public.marketplace_products
  (name, slug, description, price_cents, currency, stripe_price_id, template_id)
select
  'AI Local Business Launch Package',
  'ai-local-business-launch',
  'A starter business website package with AI-generated core pages and marketing foundations.',
  9900,
  'usd',
  null,
  t.id
from public.templates t
where t.slug = 'professional-local-business'
and not exists (
  select 1 from public.marketplace_products p
  where p.slug = 'ai-local-business-launch'
);
