import type { NextConfig } from "next";
const nextConfig: NextConfig = {
  reactStrictMode: true,
};
export default nextConfig;
.gitignore
node_modules/
.next/
out/
.env
.env.local
.env.*.local
!.env.example
*.log
.DS_Store
supabase/.temp/
license-keys/
*.pem
