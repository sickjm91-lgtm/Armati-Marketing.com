import { generateKeyPair, exportPKCS8, exportSPKI } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
await mkdir("license-keys", { recursive: true });
const { publicKey, privateKey } = await new Promise((resolve, reject) => {
  generateKeyPair("ed25519", {}, (error, keys) => error ? reject(error) : resolve(keys));
});
await writeFile("license-keys/private.pem", await exportPKCS8(privateKey));
await writeFile("license-keys/public.pem", await exportSPKI(publicKey));
console.log("Created license-keys/private.pem and license-keys/public.pem");
console.log("KEEP private.pem OFF GitHub and out of the application server unless your licensing service needs it.");
