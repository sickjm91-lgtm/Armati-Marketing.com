import { readFile } from "node:fs/promises";
import { importPKCS8 } from "jose";
import { SignJWT } from "jose";
const path = process.env.LICENSE_PRIVATE_KEY_PATH || "license-keys/private.pem";
const key = await importPKCS8(await readFile(path, "utf8"), "EdDSA");
const expires = process.env.LICENSE_EXPIRES_AT
  ? Math.floor(new Date(process.env.LICENSE_EXPIRES_AT).getTime() / 1000)
  : Math.floor(Date.now() / 1000) + 31536000;
const token = await new SignJWT({
  product: process.env.LICENSE_PRODUCT || "armati-marketing",
  installations: process.env.LICENSE_INSTALLATIONS
    ? process.env.LICENSE_INSTALLATIONS.split(",").map((x) => x.trim()).filter(Boolean)
    : [],
  features: ["website-builder", "ai-builder", "marketplace", "billing"]
})
  .setProtectedHeader({ alg: "EdDSA" })
  .setSubject(process.env.LICENSE_CUSTOMER_ID || "development-customer")
  .setIssuer(process.env.LICENSE_ISSUER || "armati-marketing")
  .setAudience(process.env.LICENSE_AUDIENCE || "armati-marketing-client")
  .setIssuedAt()
  .setExpirationTime(expires)
  .sign(key);
console.log(token);
LICENSE
MIT License
Copyright (c) 2026 ArmatiMarketing.Com
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files, to deal in the Software
without restriction, including without limitation the rights to use, copy,
modify, merge, publish, distribute, sublicense, and/or sell copies of the
Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
