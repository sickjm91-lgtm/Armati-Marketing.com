# ArmatiMarketing.Com
A GitHub-ready starter for a multi-tenant AI website SaaS and ready-to-go online business marketplace.
## What is included
- Next.js + TypeScript application
- Supabase Auth/PostgreSQL integration
- Workspace and membership model
- PostgreSQL Row Level Security (RLS)
- AI website generation using OpenAI Responses API with structured JSON output
- Template catalog and template cloning foundation
- Stripe Checkout session creation
- Stripe webhook verification
- Subscription record handling
- Customer dashboard
- Admin dashboard foundation
- License activation and signed license verification
- Environment-variable based secrets
- SQL migrations and seed data
- Secure defaults and explicit production TODOs
The earlier product specification calls for customer isolation, AI generation, template cloning, marketplace products, billing, publishing, admin tools, and white-label configuration. This starter implements the foundation for those capabilities.
## 1. Prerequisites
Install:
- Node.js 20+ (use the current supported LTS for production)
- npm
- A GitHub account
- A Supabase project
- An OpenAI API key
- A Stripe account for payments
- A deployment provider such as Vercel
## 2. Install
```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd ArmatiMarketing.Com
npm install
cp .env.example .env.local
```
Fill `.env.local` with your real credentials.
## 3. Supabase
Create a Supabase project, then run:
```text
