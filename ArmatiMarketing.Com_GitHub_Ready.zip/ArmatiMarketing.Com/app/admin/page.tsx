import { requireAdmin } from "@/lib/auth";

export default async function AdminPage() {
  const user = await requireAdmin();
  return (
    <main className="container">
      <h1>Admin Dashboard</h1>
      <p className="muted">Authorized administrator: {user.email}</p>
      <div className="grid">
        <div className="card"><h2>Customers</h2><p>Manage accounts and workspaces.</p></div>
        <div className="card"><h2>Templates</h2><p>Version and activate reusable templates.</p></div>
        <div className="card"><h2>Marketplace</h2><p>Manage products and pricing.</p></div>
        <div className="card"><h2>Operations</h2><p>Review AI jobs, subscriptions and publishing status.</p></div>
      </div>
    </main>
  );
}
