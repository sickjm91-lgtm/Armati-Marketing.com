import Link from "next/link";

export default function HomePage() {
  return (
    <>
      <nav>
        <strong>ArmatiMarketing.Com</strong>
        <div className="links">
          <Link href="/marketplace">Marketplace</Link>
          <Link href="/dashboard">Dashboard</Link>
          <Link href="/admin">Admin</Link>
        </div>
      </nav>
      <main>
        <section className="hero">
          <h1>Launch a business with AI.</h1>
          <p>
            Build reusable websites, customize ready-to-go business packages,
            generate content with AI, collect leads, and manage customers from one platform.
          </p>
          <Link className="button" href="/marketplace">Explore business packages</Link>
        </section>
        <section className="container grid">
          <div className="card"><h2>AI Builder</h2><p className="muted">Generate structured pages, offers, SEO metadata and calls-to-action.</p></div>
          <div className="card"><h2>Templates</h2><p className="muted">Clone versioned templates into isolated customer workspaces.</p></div>
          <div className="card"><h2>Commerce</h2><p className="muted">Use Stripe Checkout and verified webhooks for purchases and subscriptions.</p></div>
          <div className="card"><h2>Licensing</h2><p className="muted">Protect commercial deployments with signed activation licenses.</p></div>
        </section>
      </main>
    </>
  );
}
