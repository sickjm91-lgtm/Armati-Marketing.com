import { NextResponse } from "next/server";
import OpenAI from "openai";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { createServerSupabaseClient } from "@/lib/supabase/server";

const inputSchema = z.object({
  workspaceId: z.string().uuid(),
  businessName: z.string().min(2).max(120),
  industry: z.string().min(2).max(100),
  targetCustomer: z.string().min(2).max(300),
  offer: z.string().min(2).max(500),
  location: z.string().max(150).optional().default(""),
  goal: z.string().min(2).max(200),
  personality: z.string().max(150).optional().default("professional"),
});

const sitePlanSchema = {
  type: "object",
  additionalProperties: false,
  properties: {
    siteTitle: { type: "string" },
    navigation: { type: "array", items: { type: "string" } },
    pages: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        properties: {
          slug: { type: "string" },
          title: { type: "string" },
          seoTitle: { type: "string" },
          seoDescription: { type: "string" },
          sections: {
            type: "array",
            items: {
              type: "object",
              additionalProperties: false,
              properties: {
                type: { type: "string" },
                heading: { type: "string" },
                body: { type: "string" },
                cta: { type: "string" }
              },
              required: ["type", "heading", "body", "cta"]
            }
          }
        },
        required: ["slug", "title", "seoTitle", "seoDescription", "sections"]
      }
    }
  },
  required: ["siteTitle", "navigation", "pages"]
} as const;

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const body = inputSchema.parse(await request.json());
    const supabase = await createServerSupabaseClient();

    const { data: membership } = await supabase
      .from("workspace_members")
      .select("workspace_id")
      .eq("workspace_id", body.workspaceId)
      .eq("user_id", user.id)
      .maybeSingle();

    if (!membership) {
      return NextResponse.json({ error: "Workspace access denied." }, { status: 403 });
    }

    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5",
      input: [
        {
          role: "system",
          content: "You create concise, conversion-focused website plans. Return only the requested structured data. Never output executable HTML, JavaScript, CSS, SQL, or credentials."
        },
        {
          role: "user",
          content: JSON.stringify(body)
        }
      ],
      text: {
        format: {
          type: "json_schema",
          name: "site_plan",
          strict: true,
          schema: sitePlanSchema
        }
      }
    });

    const plan = JSON.parse(response.output_text);

    const { data: job, error: jobError } = await supabase
      .from("ai_jobs")
      .insert({
        workspace_id: body.workspaceId,
        user_id: user.id,
        job_type: "site_generation",
        status: "completed",
        input: body,
        output: plan
      })
      .select("id,status")
      .single();

    if (jobError) throw jobError;

    return NextResponse.json({ job, plan });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "AI generation failed." }, { status: 500 });
  }
}
