import { NextResponse } from "next/server";
import Stripe from "stripe";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { createServerSupabaseClient } from "@/lib/supabase/server";

const schema = z.object({ productId: z.string().uuid() });

export async function POST(request: Request) {
  try {
    const user = await requireUser();
    const { productId } = schema.parse(await request.json());
    const supabase = await createServerSupabaseClient();

    const { data: product } = await supabase
      .from("marketplace_products")
      .select("id,name,stripe_price_id,active")
      .eq("id", productId)
      .eq("active", true)
      .single();

    if (!product?.stripe_price_id) {
      return NextResponse.json({ error: "Product is not configured for checkout." }, { status: 400 });
    }

    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
    const appUrl = process.env.NEXT_PUBLIC_APP_URL!;

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price: product.stripe_price_id, quantity: 1 }],
      success_url: `${appUrl}/dashboard?checkout=success`,
      cancel_url: `${appUrl}/marketplace?checkout=cancelled`,
      customer_email: user.email ?? undefined,
      metadata: {
        user_id: user.id,
        product_id: product.id,
      },
      subscription_data: {
        metadata: {
          user_id: user.id,
          product_id: product.id,
        }
      }
    });

    return NextResponse.json({ url: session.url });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Unable to create checkout." }, { status: 500 });
  }
}
