create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  owner_id uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now()
);

create table if not exists public.workspace_members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('owner','admin','editor','viewer')),
  created_at timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

create table if not exists public.templates (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  version integer not null default 1,
  active boolean not null default true,
  schema jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.sites (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  template_id uuid references public.templates(id),
  name text not null,
  slug text not null,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  created_at timestamptz not null default now(),
  unique(workspace_id, slug)
);

create table if not exists public.pages (
  id uuid primary key default gen_random_uuid(),
  site_id uuid not null references public.sites(id) on delete cascade,
  slug text not null,
  title text not null,
  content jsonb not null default '{}'::jsonb,
  seo_title text,
  seo_description text,
  status text not null default 'draft' check (status in ('draft','published')),
  updated_at timestamptz not null default now(),
  unique(site_id, slug)
);

create table if not exists public.marketplace_products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text,
  price_cents integer not null default 0 check (price_cents >= 0),
  currency text not null default 'usd',
  stripe_price_id text,
  template_id uuid references public.templates(id),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  stripe_subscription_id text not null unique,
  stripe_customer_id text,
  user_id uuid references auth.users(id) on delete set null,
  product_id uuid references public.marketplace_products(id),
  status text not null,
  current_period_end timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  name text,
  email text,
  source text,
  status text not null default 'new',
  created_at timestamptz not null default now()
);

create table if not exists public.ai_jobs (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  job_type text not null,
  status text not null,
  input jsonb not null default '{}'::jsonb,
  output jsonb,
  error text,
  created_at timestamptz not null default now()
);

create table if not exists public.billing_events (
  id uuid primary key default gen_random_uuid(),
  stripe_event_id text unique,
  event_type text not null,
  user_id uuid references auth.users(id) on delete set null,
  product_id uuid references public.marketplace_products(id),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.is_workspace_member(target_workspace uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.workspace_members
    where workspace_id = target_workspace
      and user_id = auth.uid()
  );
$$;

create or replace function public.is_workspace_admin(target_workspace uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.workspace_members
    where workspace_id = target_workspace
      and user_id = auth.uid()
      and role in ('owner','admin')
  );
$$;

alter table public.profiles enable row level security;
alter table public.workspaces enable row level security;
alter table public.workspace_members enable row level security;
alter table public.templates enable row level security;
alter table public.sites enable row level security;
alter table public.pages enable row level security;
alter table public.marketplace_products enable row level security;
alter table public.subscriptions enable row level security;
alter table public.leads enable row level security;
alter table public.ai_jobs enable row level security;
alter table public.billing_events enable row level security;

create policy "profiles own row"
on public.profiles for select
using (id = auth.uid());

create policy "workspaces member read"
on public.workspaces for select
using (public.is_workspace_member(id));

create policy "members read own workspace"
on public.workspace_members for select
using (public.is_workspace_member(workspace_id));

create policy "templates public read"
on public.templates for select
using (active = true);

create policy "sites member access"
on public.sites for all
using (public.is_workspace_member(workspace_id))
with check (public.is_workspace_member(workspace_id));

create policy "pages member access"
on public.pages for all
using (
  exists (
    select 1 from public.sites s
    where s.id = pages.site_id
      and public.is_workspace_member(s.workspace_id)
  )
)
with check (
  exists (
    select 1 from public.sites s
    where s.id = pages.site_id
      and public.is_workspace_member(s.workspace_id)
  )
);

create policy "products public read"
on public.marketplace_products for select
using (active = true);

create policy "subscriptions own read"
on public.subscriptions for select
using (user_id = auth.uid());

create policy "leads member access"
on public.leads for all
using (public.is_workspace_member(workspace_id))
with check (public.is_workspace_member(workspace_id));

create policy "ai jobs member read"
on public.ai_jobs for select
using (public.is_workspace_member(workspace_id));

create policy "ai jobs member insert"
on public.ai_jobs for insert
with check (public.is_workspace_member(workspace_id) and user_id = auth.uid());

create policy "billing events own read"
on public.billing_events for select
using (user_id = auth.uid());

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id) values (new.id)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
