import { readFile } from "node:fs/promises";
import { importPKCS8 } from "jose";
import { SignJWT } from "jose";

const path = process.env.LICENSE_PRIVATE_KEY_PATH || "license-keys/private.pem";
const key = await importPKCS8(await readFile(path, "utf8"), "EdDSA");

const expires = process.env.LICENSE_EXPIRES_AT
  ? Math.floor(new Date(process.env.LICENSE_EXPIRES_AT).getTime() / 1000)
  : Math.floor(Date.now() / 1000) + 31536000;

const token = await new SignJWT({
  product: process.env.LICENSE_PRODUCT || "armati-marketing",
  installations: process.env.LICENSE_INSTALLATIONS
    ? process.env.LICENSE_INSTALLATIONS.split(",").map((x) => x.trim()).filter(Boolean)
    : [],
  features: ["website-builder", "ai-builder", "marketplace", "billing"]
})
  .setProtectedHeader({ alg: "EdDSA" })
  .setSubject(process.env.LICENSE_CUSTOMER_ID || "development-customer")
  .setIssuer(process.env.LICENSE_ISSUER || "armati-marketing")
  .setAudience(process.env.LICENSE_AUDIENCE || "armati-marketing-client")
  .setIssuedAt()
  .setExpirationTime(expires)
  .sign(key);

console.log(token);
